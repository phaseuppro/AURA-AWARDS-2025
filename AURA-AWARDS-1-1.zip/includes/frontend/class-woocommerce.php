<?php
// WooCommerce Integration Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_WooCommerce {

    public function __construct() {
        add_action('init', [$this, 'register_credits_product']);
        add_action('woocommerce_account_menu_items', [$this, 'add_account_tabs']);
        add_action('woocommerce_account_credits_endpoint', [$this, 'render_credits_tab']);
        add_action('woocommerce_account_submissions_endpoint', [$this, 'render_submissions_tab']);
        add_action('woocommerce_order_status_completed', [$this, 'add_credits_on_purchase']);
    }

    public function register_credits_product() {
        if (!get_option('aura_credits_product_created')) {
            $product_id = wp_insert_post([
                'post_title' => 'Photo Credits',
                'post_content' => 'Purchase credits for contest submissions.',
                'post_status' => 'publish',
                'post_type' => 'product'
            ]);

            if ($product_id) {
                wp_set_object_terms($product_id, 'simple', 'product_type');
                update_post_meta($product_id, '_price', '10');
                update_post_meta($product_id, '_stock_status', 'instock');
                update_post_meta($product_id, '_manage_stock', 'no');
                update_post_meta($product_id, '_virtual', 'yes');
                update_option('aura_credits_product_created', true);
            }
        }
    }

    public function add_account_tabs($items) {
        $items['credits'] = 'Credits';
        $items['submissions'] = 'My Submissions';
        return $items;
    }

    public function render_credits_tab() {
        $user_id = get_current_user_id();
        $credits = (int) get_user_meta($user_id, 'aura_credits', true);

        echo '<h2>Your Credits</h2>';
        echo '<p>You currently have <strong>' . $credits . '</strong> credits available.</p>';
        echo '<a href="' . esc_url(wc_get_page_permalink('shop')) . '" class="button">Buy More Credits</a>';
    }

    public function render_submissions_tab() {
        global $wpdb;
        $user_id = get_current_user_id();
        $submissions = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aura_submissions WHERE user_id = %d",
                $user_id
            ),
            ARRAY_A
        );

        echo '<h2>Your Submissions</h2>';

        if (empty($submissions)) {
            echo '<p>You have no submissions yet.</p>';
            return;
        }

        echo '<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive">';
        echo '<thead><tr><th>Image</th><th>Title</th><th>Category</th><th>Badge</th><th>Points</th></tr></thead><tbody>';

        foreach ($submissions as $submission) {
            $image_url = wp_get_attachment_url($submission['image_id']);
            $badge = $submission['badge'] ?: 'Pending';
            $score = $submission['score'] ?: 'N/A';

            echo '<tr>';
            echo '<td><img src="' . esc_url($image_url) . '" alt="' . esc_attr($submission['title']) . '" width="50"></td>';
            echo '<td>' . esc_html($submission['title']) . '</td>';
            echo '<td>' . esc_html($submission['category']) . '</td>';
            echo '<td>' . esc_html($badge) . '</td>';
            echo '<td>' . esc_html($score) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    public function add_credits_on_purchase($order_id) {
        $order = wc_get_order($order_id);

        if (!$order) {
            return;
        }

        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();
            $product = wc_get_product($product_id);

            if ($product && $product->get_name() === 'Photo Credits') {
                $quantity = $item->get_quantity();
                $user_id = $order->get_user_id();

                $current_credits = (int) get_user_meta($user_id, 'aura_credits', true);
                $new_credits = $current_credits + $quantity;

                update_user_meta($user_id, 'aura_credits', $new_credits);
            }
        }
    }
}
