<?php
// User Dashboard Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_User_Dashboard {

    public function __construct() {
        add_shortcode('aura_user_dashboard', [$this, 'render_user_dashboard']);
    }

    public function render_user_dashboard() {
        global $wpdb;

        $current_date = current_time('mysql');
        $contests = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}aura_contests ORDER BY start_date DESC",
            ARRAY_A
        );

        if (empty($contests)) {
            return '<p>No contests available at the moment.</p>';
        }

        ob_start();
        ?>
        <div class="aura-user-dashboard">
            <h2>Active and Upcoming Contests</h2>
            <table class="aura-dashboard-table">
                <thead>
                    <tr>
                        <th>Contest Name</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($contests as $contest) : ?>
                        <tr>
                            <td><?php echo esc_html($contest['name']); ?></td>
                            <td><?php echo esc_html(date('Y-m-d', strtotime($contest['start_date']))); ?></td>
                            <td><?php echo esc_html(date('Y-m-d', strtotime($contest['end_date']))); ?></td>
                            <td>
                                <?php
                                if ($current_date < $contest['start_date']) {
                                    echo '<span class="status upcoming">Upcoming</span>';
                                } elseif ($current_date > $contest['end_date']) {
                                    echo '<span class="status ended">Ended</span>';
                                } else {
                                    echo '<span class="status active">Active</span>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php if ($current_date <= $contest['end_date']) : ?>
                                    <a href="<?php echo esc_url(get_permalink() . '?contest_id=' . $contest['id']); ?>" class="button">Submit</a>
                                <?php else : ?>
                                    <span>N/A</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <style>
            .aura-dashboard-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            .aura-dashboard-table th, .aura-dashboard-table td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }
            .aura-dashboard-table th {
                background-color: #f4f4f4;
            }
            .status.upcoming {
                color: orange;
            }
            .status.ended {
                color: red;
            }
            .status.active {
                color: green;
            }
        </style>
        <?php
        return ob_get_clean();
    }
}
