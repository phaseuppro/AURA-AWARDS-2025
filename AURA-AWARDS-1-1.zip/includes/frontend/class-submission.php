<?php
// Submission Management Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_Submission {

    public function __construct() {
        add_shortcode('aura_submission', [$this, 'render_submission_form']);
        add_shortcode('aura_upload_form', [$this, 'render_upload_form']);
        add_action('wp_ajax_aura_submit_photo', [$this, 'handle_submission']);
        add_action('wp_ajax_nopriv_aura_submit_photo', [$this, 'handle_submission']);
    }

    public function render_submission_form($atts) {
        $atts = shortcode_atts(['contest_id' => 0], $atts);
        $contest_id = (int) $atts['contest_id'];

        if (!$contest_id) {
            return '<p>Invalid contest ID.</p>';
        }

        ob_start();
        ?>
        <form id="aura-submission-form" method="post" enctype="multipart/form-data">
            <input type="hidden" name="contest_id" value="<?php echo esc_attr($contest_id); ?>">
            <p><label for="photo">Upload Photo:</label>
                <input type="file" name="photo" id="photo" required accept="image/*"></p>
            <p><label for="title">Title:</label>
                <input type="text" name="title" id="title" required></p>
            <p><label for="category">Category:</label>
                <select name="category" id="category">
                    <option value="Maternity">Maternity</option>
                    <option value="Newborn">Newborn</option>
                    <option value="Children">Children</option>
                    <option value="Families">Families</option>
                    <option value="AI-Infused">AI-Infused</option>
                </select></p>
            <p><button type="submit">Submit</button></p>
        </form>
        <div id="aura-submission-response"></div>
        <script>
            document.getElementById('aura-submission-form').addEventListener('submit', function (e) {
                e.preventDefault();
                const formData = new FormData(this);
                const progressBar = document.createElement('progress');
                progressBar.max = 100;
                progressBar.value = 0;
                this.appendChild(progressBar);

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Accept': 'application/json',
                    }
                }).then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                }).then(data => {
                    const responseDiv = document.getElementById('aura-submission-response');
                    responseDiv.innerHTML = data.message;
                    if (data.success) {
                        responseDiv.style.color = 'green';
                        this.reset();
                    } else {
                        responseDiv.style.color = 'red';
                    }
                    progressBar.remove();
                }).catch(error => {
                    console.error('There was a problem with the fetch operation:', error);
                    const responseDiv = document.getElementById('aura-submission-response');
                    responseDiv.innerHTML = 'Submission failed. Please try again.';
                    responseDiv.style.color = 'red';
                    progressBar.remove();
                });
            });
        </script>
        <?php
        return ob_get_clean();
    }

    public function handle_submission() {
        if (!isset($_POST['contest_id'], $_FILES['photo'])) {
            wp_send_json_error(['message' => 'Invalid submission data.']);
        }

        $contest_id = (int) $_POST['contest_id'];
        $title = sanitize_text_field($_POST['title']);
        $category = sanitize_text_field($_POST['category']);

        $file = $_FILES['photo'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message' => 'File upload error.']);
        }

        // Validate image size
        list($width, $height) = getimagesize($file['tmp_name']);
        if ($width < 2048 || $height < 2048 || max($width, $height) > 3000) {
            wp_send_json_error(['message' => 'Image dimensions must be at least 2048px on the shortest side and not exceed 3000px on the longest side.']);
        }

        $upload = wp_handle_upload($file, ['test_form' => false]);
        if (isset($upload['error'])) {
            wp_send_json_error(['message' => $upload['error']]);
        }

        $attachment_id = wp_insert_attachment(
            [
                'guid' => $upload['url'],
                'post_mime_type' => $upload['type'],
                'post_title' => sanitize_file_name($file['name']),
                'post_content' => '',
                'post_status' => 'inherit'
            ],
            $upload['file']
        );

        require_once ABSPATH . 'wp-admin/includes/image.php';
        $attach_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
        wp_update_attachment_metadata($attachment_id, $attach_data);

        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'aura_submissions', [
            'contest_id' => $contest_id,
            'image_id' => $attachment_id,
            'title' => $title,
            'category' => $category,
            'status' => 'pending',
            'created_at' => current_time('mysql')
        ]);

        wp_send_json_success(['message' => 'Submission successful!']);
    }
}
