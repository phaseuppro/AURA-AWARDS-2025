<?php
// Gallery Management Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_Gallery {

    public function __construct() {
        add_shortcode('aura_gallery', [$this, 'render_gallery']);
        add_action('wp_ajax_load_more_gallery', [$this, 'load_more_gallery']);
        add_action('wp_ajax_nopriv_load_more_gallery', [$this, 'load_more_gallery']);
    }

    public function render_gallery($atts) {
        $atts = shortcode_atts(['contest_id' => 0], $atts);
        $contest_id = (int) $atts['contest_id'];

        if (!$contest_id) {
            return '<p>Invalid contest ID.</p>';
        }

        global $wpdb;
        $submissions = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aura_submissions WHERE contest_id = %d AND status = 'judged' LIMIT 10",
                $contest_id
            ),
            ARRAY_A
        );

        if (empty($submissions)) {
            return '<p>No judged submissions available for this contest.</p>';
        }

        ob_start();
        ?>
        <div id="aura-gallery">
            <div id="aura-gallery-grid">
                <?php foreach ($submissions as $submission) : ?>
                    <div class="aura-gallery-item" data-id="<?php echo esc_attr($submission['id']); ?>">
                        <img src="<?php echo esc_url(wp_get_attachment_url($submission['image_id'])); ?>" alt="<?php echo esc_attr($submission['title']); ?>">
                        <p><?php echo esc_html($submission['title']); ?></p>
                        <p><strong>Badge:</strong> <?php echo esc_html($submission['badge']); ?></p>
                        <p><strong>Category:</strong> <?php echo esc_html($submission['category']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
            <button id="aura-load-more" data-page="1" data-contest-id="<?php echo esc_attr($contest_id); ?>">Load More</button>
        </div>
        <script>
            document.getElementById('aura-load-more').addEventListener('click', function () {
                const button = this;
                const page = parseInt(button.dataset.page, 10) + 1;
                const contestId = button.dataset.contestId;

                fetch(`<?php echo admin_url('admin-ajax.php'); ?>?action=load_more_gallery&page=${page}&contest_id=${contestId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const grid = document.getElementById('aura-gallery-grid');
                            grid.insertAdjacentHTML('beforeend', data.html);
                            button.dataset.page = page;

                            if (!data.has_more) {
                                button.remove();
                            }
                        } else {
                            alert(data.message);
                        }
                    });
            });
        </script>
        <?php
        return ob_get_clean();
    }

    public function load_more_gallery() {
        if (!isset($_GET['contest_id'], $_GET['page'])) {
            wp_send_json_error(['message' => 'Invalid request.']);
        }

        $contest_id = (int) $_GET['contest_id'];
        $page = (int) $_GET['page'];
        $offset = ($page - 1) * 10;

        global $wpdb;
        $submissions = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aura_submissions WHERE contest_id = %d AND status = 'judged' LIMIT 10 OFFSET %d",
                $contest_id,
                $offset
            ),
            ARRAY_A
        );

        if (empty($submissions)) {
            wp_send_json_error(['message' => 'No more submissions to load.']);
        }

        ob_start();
        foreach ($submissions as $submission) : ?>
            <div class="aura-gallery-item" data-id="<?php echo esc_attr($submission['id']); ?>">
                <img src="<?php echo esc_url(wp_get_attachment_url($submission['image_id'])); ?>" alt="<?php echo esc_attr($submission['title']); ?>">
                <p><?php echo esc_html($submission['title']); ?></p>
                <p><strong>Badge:</strong> <?php echo esc_html($submission['badge']); ?></p>
                <p><strong>Category:</strong> <?php echo esc_html($submission['category']); ?></p>
            </div>
        <?php endforeach;

        $html = ob_get_clean();
        $has_more = count($submissions) === 10;

        wp_send_json_success(['html' => $html, 'has_more' => $has_more]);
    }
}

new AURA_Gallery();

