<?php
// Admin Menu Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_Admin_Menu {

    public function __construct() {
        add_action('admin_menu', [$this, 'register_menu']);
    }

    public function register_menu() {
        // Hauptmenu
        add_menu_page(
            'AURA Photo Awards',          // Seiten-Titel
            'AURA Awards',               // Menü-Name
            'manage_options',            // Berechtigung
            'aura-main-menu',            // Menü-Slug
            [$this, 'render_dashboard'], // Callback-Funktion
            'dashicons-awards',          // Icon
            6                            // Position
        );

        // Submenu: Wettbewerbsverwaltung
        add_submenu_page(
            'aura-main-menu',            // Parent-Slug
            'Wettbewerbsverwaltung',     // Seiten-Titel
            'Contests',                 // Menü-Name
            'manage_options',           // Berechtigung
            'aura-contests',            // Menü-Slug
            [$this, 'render_contests']  // Callback-Funktion
        );

        // Submenu: Judging
        add_submenu_page(
            'aura-main-menu',
            'Judging Panel',
            'Judging',
            'manage_options',
            'aura-judging',
            [$this, 'render_judging']
        );
    }

    // Callback-Funktion für Dashboard
    public function render_dashboard() {
        echo '<div class="wrap"><h1>AURA Photo Awards Dashboard</h1>';
        echo '<p>Willkommen im Admin-Panel der AURA Photo Awards!</p>';
        echo '<ul>';
        echo '<li>Wettbewerbe insgesamt: ' . $this->get_total_contests() . '</li>';
        echo '<li>Gesamte Einreichungen: ' . $this->get_total_submissions() . '</li>';
        echo '</ul></div>';
    }

    // Hilfsfunktionen für Statistiken
    private function get_total_contests() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aura_contests';
        return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    }

    private function get_total_submissions() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aura_submissions';
        return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    }

    // Callback-Funktion für Wettbewerbsverwaltung
    public function render_contests() {
        echo '<div class="wrap"><h1>Wettbewerbsverwaltung</h1>';
        echo '<form method="post">';
        echo '<h2>Neuen Wettbewerb erstellen</h2>';
        echo '<table class="form-table">';
        echo '<tr><th><label for="contest_name">Wettbewerbsname</label></th>';
        echo '<td><input type="text" name="contest_name" id="contest_name" required></td></tr>';
        echo '<tr><th><label for="start_date">Startdatum</label></th>';
        echo '<td><input type="date" name="start_date" id="start_date" required></td></tr>';
        echo '<tr><th><label for="end_date">Enddatum</label></th>';
        echo '<td><input type="date" name="end_date" id="end_date" required></td></tr>';
        echo '</table>';
        echo '<button type="submit" name="create_contest" class="button button-primary">Wettbewerb erstellen</button>';
        echo '</form>';

        if (isset($_POST['create_contest'])) {
            $this->create_new_contest($_POST['contest_name'], $_POST['start_date'], $_POST['end_date']);
        }

        echo '<h2>Bestehende Wettbewerbe</h2>';
        $this->display_contests_table();
        echo '</div>';
    }

    private function create_new_contest($name, $start_date, $end_date) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aura_contests';
        $wpdb->insert($table_name, [
            'name' => sanitize_text_field($name),
            'start_date' => sanitize_text_field($start_date),
            'end_date' => sanitize_text_field($end_date),
        ]);
        echo '<div class="updated"><p>Neuer Wettbewerb erstellt!</p></div>';
    }

    private function display_contests_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aura_contests';
        $contests = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

        if (empty($contests)) {
            echo '<p>Keine Wettbewerbe vorhanden.</p>';
            return;
        }

        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>ID</th><th>Name</th><th>Startdatum</th><th>Enddatum</th></tr></thead>';
        echo '<tbody>';
        foreach ($contests as $contest) {
            echo '<tr>';
            echo '<td>' . esc_html($contest['id']) . '</td>';
            echo '<td>' . esc_html($contest['name']) . '</td>';
            echo '<td>' . esc_html($contest['start_date']) . '</td>';
            echo '<td>' . esc_html($contest['end_date']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    // Callback-Funktion für Judging
    public function render_judging() {
        echo '<div class="wrap"><h1>Judging Panel</h1>';
        echo '<p>Hier kannst du Einreichungen bewerten.</p>';
        $this->display_judging_table();
        echo '</div>';
    }

    private function display_judging_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aura_submissions';
        $submissions = $wpdb->get_results("SELECT * FROM $table_name WHERE status = 'pending'", ARRAY_A);

        if (empty($submissions)) {
            echo '<p>Keine Einreichungen zu bewerten.</p>';
            return;
        }

        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>ID</th><th>Bild</th><th>Titel</th><th>Kategorie</th><th>Bewerten</th></tr></thead>';
        echo '<tbody>';
        foreach ($submissions as $submission) {
            $image_url = wp_get_attachment_url($submission['image_id']);
            echo '<tr>';
            echo '<td>' . esc_html($submission['id']) . '</td>';
            echo '<td><img src="' . esc_url($image_url) . '" alt="" width="50"></td>';
            echo '<td>' . esc_html($submission['title']) . '</td>';
            echo '<td>' . esc_html($submission['category']) . '</td>';
            echo '<td><a href="#" class="button">Bewerten</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }
}

new AURA_Admin_Menu();
