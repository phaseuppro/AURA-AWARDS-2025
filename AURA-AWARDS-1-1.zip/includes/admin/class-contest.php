<?php
// Contest Management Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_Contest {

    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'aura_contests';
        add_action('admin_menu', [$this, 'register_admin_menu']);
    }

    public function create_contest($name, $start_date, $end_date) {
        global $wpdb;

        $wpdb->insert($this->table_name, [
            'name' => $name,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'created_at' => current_time('mysql')
        ]);

        $contest_id = $wpdb->insert_id;
        $this->generate_pages_for_contest($contest_id, $name);
        return $contest_id;
    }

    public function edit_contest($id, $name, $start_date, $end_date) {
        global $wpdb;

        $wpdb->update($this->table_name, [
            'name' => $name,
            'start_date' => $start_date,
            'end_date' => $end_date
        ], ['id' => $id]);
    }

    public function delete_contest($id) {
        global $wpdb;

        $wpdb->delete($this->table_name, ['id' => $id]);
    }

    public function list_contests() {
        global $wpdb;

        return $wpdb->get_results("SELECT * FROM {$this->table_name}", ARRAY_A);
    }

    private function generate_pages_for_contest($contest_id, $contest_name) {
        wp_insert_post([
            'post_title' => $contest_name . ' - Submissions',
            'post_content' => '[aura_submission contest_id="' . $contest_id . '"]',
            'post_status' => 'publish',
            'post_type' => 'page'
        ]);

        wp_insert_post([
            'post_title' => $contest_name . ' - Gallery',
            'post_content' => '[aura_gallery contest_id="' . $contest_id . '"]',
            'post_status' => 'publish',
            'post_type' => 'page'
        ]);
    }

    public function register_admin_menu() {
        add_menu_page(
            'AURA Contests',
            'Contests',
            'manage_options',
            'aura_contests',
            [$this, 'render_admin_page'],
            'dashicons-awards',
            25
        );
    }

    public function render_admin_page() {
        $contests = $this->list_contests();

        echo '<div class="wrap">';
        echo '<h1>AURA Contests</h1>';
        echo '<a href="?page=aura_contests&action=add" class="button button-primary">Add New Contest</a>';

        if (isset($_GET['action']) && $_GET['action'] === 'add') {
            $this->render_add_form();
        } elseif (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
            $this->render_edit_form((int)$_GET['id']);
        } else {
            $this->render_contests_table($contests);
        }

        echo '</div>';
    }

    private function render_add_form() {
        echo '<h2>Add New Contest</h2>';
        echo '<form method="post">';
        echo '<p><label>Name</label><input type="text" name="name" required></p>';
        echo '<p><label>Start Date</label><input type="date" name="start_date" required></p>';
        echo '<p><label>End Date</label><input type="date" name="end_date" required></p>';
        echo '<p><input type="submit" name="save_contest" class="button button-primary" value="Save"></p>';
        echo '</form>';

        if (isset($_POST['save_contest'])) {
            $this->create_contest(
                sanitize_text_field($_POST['name']),
                sanitize_text_field($_POST['start_date']),
                sanitize_text_field($_POST['end_date'])
            );
            wp_redirect(admin_url('admin.php?page=aura_contests'));
            exit;
        }
    }

    private function render_edit_form($id) {
        $contest = $this->get_contest($id);

        if (!$contest) {
            echo '<p>Contest not found.</p>';
            return;
        }

        echo '<h2>Edit Contest</h2>';
        echo '<form method="post">';
        echo '<input type="hidden" name="id" value="' . esc_attr($contest['id']) . '">';
        echo '<p><label>Name</label><input type="text" name="name" value="' . esc_attr($contest['name']) . '" required></p>';
        echo '<p><label>Start Date</label><input type="date" name="start_date" value="' . esc_attr($contest['start_date']) . '" required></p>';
        echo '<p><label>End Date</label><input type="date" name="end_date" value="' . esc_attr($contest['end_date']) . '" required></p>';
        echo '<p><input type="submit" name="update_contest" class="button button-primary" value="Update"></p>';
        echo '</form>';

        if (isset($_POST['update_contest'])) {
            $this->edit_contest(
                (int)$_POST['id'],
                sanitize_text_field($_POST['name']),
                sanitize_text_field($_POST['start_date']),
                sanitize_text_field($_POST['end_date'])
            );
            wp_redirect(admin_url('admin.php?page=aura_contests'));
            exit;
        }
    }

    private function render_contests_table($contests) {
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>ID</th><th>Name</th><th>Start Date</th><th>End Date</th><th>Actions</th></tr></thead><tbody>';

        foreach ($contests as $contest) {
            echo '<tr>';
            echo '<td>' . esc_html($contest['id']) . '</td>';
            echo '<td>' . esc_html($contest['name']) . '</td>';
            echo '<td>' . esc_html($contest['start_date']) . '</td>';
            echo '<td>' . esc_html($contest['end_date']) . '</td>';
            echo '<td><a href="?page=aura_contests&action=edit&id=' . esc_attr($contest['id']) . '" class="button">Edit</a> ';
            echo '<a href="?page=aura_contests&action=delete&id=' . esc_attr($contest['id']) . '" class="button">Delete</a></td>';
            echo '</tr>';
        }

        echo '</tbody></table>';

        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
            $this->delete_contest((int)$_GET['id']);
            wp_redirect(admin_url('admin.php?page=aura_contests'));
            exit;
        }
    }

    public function get_contest($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $id), ARRAY_A);
    }
}
