<?php
// Judging Management Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_Judging {

    private $badge_thresholds = [
        'participant' => 0,
        'bronze' => 30,
        'silver' => 60,
        'gold' => 80,
        'platinum' => 90
    ];

    public function __construct() {
        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('wp_ajax_aura_save_judgment', [$this, 'save_judgment']);
    }

    public function register_admin_menu() {
        add_submenu_page(
            'aura_contests',
            'Judging',
            'Judging',
            'manage_options',
            'aura_judging',
            [$this, 'render_judging_page']
        );
    }

    public function render_judging_page() {
        global $wpdb;

        $submissions = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}aura_submissions WHERE status = 'pending'", ARRAY_A);

        echo '<div class="wrap">';
        echo '<h1>Judging</h1>';

        if (empty($submissions)) {
            echo '<p>No submissions to judge.</p>';
            return;
        }

        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>Image</th><th>Title</th><th>Category</th><th>Action</th></tr></thead><tbody>';

        foreach ($submissions as $submission) {
            $image_url = wp_get_attachment_url($submission['image_id']);

            echo '<tr>';
            echo '<td><img src="' . esc_url($image_url) . '" alt="' . esc_attr($submission['title']) . '" width="100"></td>';
            echo '<td>' . esc_html($submission['title']) . '</td>';
            echo '<td>' . esc_html($submission['category']) . '</td>';
            echo '<td><button class="button aura-judge" data-id="' . esc_attr($submission['id']) . '">Judge</button></td>';
            echo '</tr>';
        }

        echo '</tbody></table>';

        echo '<div id="aura-judging-modal" style="display:none;">';
        echo '<h2>Judge Submission</h2>';
        echo '<form id="aura-judging-form">';
        echo '<input type="hidden" name="submission_id" id="aura-submission-id">';
        for ($i = 1; $i <= 5; $i++) {
            echo '<p><label>Criteria ' . $i . '</label><input type="number" name="criteria_' . $i . '" min="0" max="10" required></p>';
        }
        echo '<p><button type="submit" class="button button-primary">Save</button></p>';
        echo '</form>';
        echo '</div>';

        echo '<script>
            document.querySelectorAll(".aura-judge").forEach(button => {
                button.addEventListener("click", function() {
                    const submissionId = this.dataset.id;
                    document.getElementById("aura-submission-id").value = submissionId;
                    document.getElementById("aura-judging-modal").style.display = "block";
                });
            });

            document.getElementById("aura-judging-form").addEventListener("submit", function(e) {
                e.preventDefault();
                const formData = new FormData(this);

                fetch("' . admin_url('admin-ajax.php') . '", {
                    method: "POST",
                    body: formData
                }).then(response => response.json()).then(data => {
                    if (data.success) {
                        alert("Judgment saved successfully!");
                        location.reload();
                    } else {
                        alert("Error: " + data.message);
                    }
                });
            });
        </script>';
        echo '</div>';
    }

    public function save_judgment() {
        if (!isset($_POST['submission_id'])) {
            wp_send_json_error(['message' => 'Invalid submission ID.']);
        }

        $submission_id = (int) $_POST['submission_id'];
        $criteria = array_map('intval', array_slice($_POST, 1, 5));
        $total_score = array_sum($criteria) * 2; // Scale to 100 points

        $badge = $this->assign_badge($total_score);

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'aura_submissions',
            [
                'status' => 'judged',
                'score' => $total_score,
                'badge' => $badge
            ],
            ['id' => $submission_id]
        );

        wp_send_json_success(['message' => 'Judgment saved.']);
    }

    private function assign_badge($score) {
        foreach ($this->badge_thresholds as $badge => $threshold) {
            if ($score >= $threshold) {
                $assigned_badge = $badge;
            }
        }
        return $assigned_badge;
    }
}
