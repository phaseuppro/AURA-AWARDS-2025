<?php
// Deactivator Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_Deactivator {

    public static function deactivate() {
        // Beispiel: Entfernen von geplanten Aufgaben
        wp_clear_scheduled_hook('aura_check_notifications');
    }
}
