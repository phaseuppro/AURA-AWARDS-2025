<?php
// Notifications Management Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_Notifications {

    public function __construct() {
        add_action('init', [$this, 'schedule_notifications_check']);
        add_action('aura_check_notifications', [$this, 'check_and_send_notifications']);
        add_action('woocommerce_account_menu_items', [$this, 'add_notifications_tab']);
        add_action('woocommerce_account_notifications_endpoint', [$this, 'render_notifications_tab']);
    }

    public function schedule_notifications_check() {
        if (!wp_next_scheduled('aura_check_notifications')) {
            wp_schedule_event(time(), 'hourly', 'aura_check_notifications');
        }
    }

    public function check_and_send_notifications() {
        global $wpdb;

        $current_date = current_time('mysql');

        // Notify users about judged submissions
        $judged_submissions = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}aura_submissions WHERE status = 'judged' AND notified = 0",
            ARRAY_A
        );

        foreach ($judged_submissions as $submission) {
            $user = get_userdata($submission['user_id']);

            if ($user) {
                wp_mail(
                    $user->user_email,
                    'Your Submission has been Judged',
                    sprintf(
                        'Your submission "%s" has been judged and received a badge: %s.',
                        $submission['title'],
                        ucfirst($submission['badge'])
                    )
                );

                // Mark as notified
                $wpdb->update(
                    $wpdb->prefix . 'aura_submissions',
                    ['notified' => 1],
                    ['id' => $submission['id']]
                );
            }
        }

        // Notify admins about new submissions
        $new_submissions = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}aura_submissions WHERE status = 'pending' AND admin_notified = 0",
            ARRAY_A
        );

        foreach ($new_submissions as $submission) {
            $admins = get_users(['role' => 'administrator']);

            foreach ($admins as $admin) {
                wp_mail(
                    $admin->user_email,
                    'New Submission Received',
                    sprintf(
                        'A new submission "%s" has been made in contest ID %d.',
                        $submission['title'],
                        $submission['contest_id']
                    )
                );
            }

            // Mark as notified
            $wpdb->update(
                $wpdb->prefix . 'aura_submissions',
                ['admin_notified' => 1],
                ['id' => $submission['id']]
            );
        }
    }

    public function add_notifications_tab($items) {
        $items['notifications'] = 'Notifications';
        return $items;
    }

    public function render_notifications_tab() {
        $user_id = get_current_user_id();
        $notifications = get_user_meta($user_id, 'aura_notifications', true) ?: [];

        echo '<h2>Your Notifications</h2>';

        if (empty($notifications)) {
            echo '<p>You have no notifications.</p>';
            return;
        }

        echo '<ul class="aura-notifications">';
        foreach ($notifications as $index => $notification) {
            echo '<li>';
            echo '<p>' . esc_html($notification['message']) . '</p>';
            echo '<small>' . esc_html($notification['date']) . '</small>';
            echo !$notification['read'] ? '<strong> (New)</strong>' : '';
            echo '</li>';
            $notifications[$index]['read'] = true; // Mark as read
        }
        echo '</ul>';

        update_user_meta($user_id, 'aura_notifications', $notifications);
    }
}
