<?php
// Loader Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_Loader {

    public function run() {
        // Lade alle notwendigen Klassen
        $this->load_classes();
    }

    private function load_classes() {
        // Beispiel: Klassen für Admin, Frontend, Core
        require_once AURA_ADMIN_PATH . 'class-contest.php';
require_once AURA_ADMIN_PATH . 'class-judging.php';
require_once AURA_FRONTEND_PATH . 'class-gallery.php';
require_once AURA_FRONTEND_PATH . 'class-user-dashboard.php';
require_once AURA_FRONTEND_PATH . 'class-submission.php';
require_once AURA_FRONTEND_PATH . 'class-woocommerce.php';
require_once AURA_CORE_PATH . 'class-notifications.php';
        // Weitere Klassen hier einfügen
    }
}
