<?php
// Activator Class for AURA Photo Awards

if (!defined('ABSPATH')) {
    exit;
}

class AURA_Activator {

    public static function activate() {
        global $wpdb;

        // Beispiel: Erstellung der Tabelle für Wettbewerbe
        $charset_collate = $wpdb->get_charset_collate();

        $table_name = $wpdb->prefix . 'aura_contests';
        $sql = "CREATE TABLE $table_name (
            id INT(11) NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            start_date DATETIME NOT NULL,
            end_date DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        // Weitere Tabellen hier hinzufügen
    }
}
