/* AURA Photo Awards Admin Scripts */

document.addEventListener('DOMContentLoaded', function () {
    // Handle Judging Modal
    const judgeButtons = document.querySelectorAll('.aura-judge');
    const judgingModal = document.getElementById('aura-judging-modal');

    judgeButtons.forEach(button => {
        button.addEventListener('click', function () {
            const submissionId = this.dataset.id;
            const submissionInput = document.getElementById('aura-submission-id');
            
            submissionInput.value = submissionId;
            judgingModal.style.display = 'block';
        });
    });

    // Close Modal
    document.getElementById('aura-judging-modal-close').addEventListener('click', function () {
        judgingModal.style.display = 'none';
    });
});
