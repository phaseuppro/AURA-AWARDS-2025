/* AURA Photo Awards Frontend Scripts */

document.addEventListener('DOMContentLoaded', function () {
    // Load More Button for Gallery
    const loadMoreButton = document.getElementById('aura-load-more');

    if (loadMoreButton) {
        loadMoreButton.addEventListener('click', function () {
            const page = parseInt(loadMoreButton.dataset.page, 10) + 1;
            const contestId = loadMoreButton.dataset.contestId;

            fetch(`?action=load_more_gallery&page=${page}&contest_id=${contestId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const galleryGrid = document.getElementById('aura-gallery-grid');
                        galleryGrid.insertAdjacentHTML('beforeend', data.html);
                        loadMoreButton.dataset.page = page;

                        if (!data.has_more) {
                            loadMoreButton.remove();
                        }
                    } else {
                        alert('No more submissions to load.');
                    }
                })
                .catch(error => {
                    console.error('Error fetching more gallery items:', error);
                });
        });
    }
});
