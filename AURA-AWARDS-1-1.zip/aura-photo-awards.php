<?php
/**
 * Plugin Name: AURA Photo Awards
 * Description: Photography contest platform with judging and badge assignment.
 * Version: 2.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('AURA_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('AURA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AURA_ADMIN_PATH', AURA_PLUGIN_PATH . 'includes/admin/');
define('AURA_FRONTEND_PATH', AURA_PLUGIN_PATH . 'includes/frontend/');
define('AURA_CORE_PATH', AURA_PLUGIN_PATH . 'includes/core/');
define('AURA_VERSION', '2.0');

// Include core files
require_once AURA_CORE_PATH . 'class-loader.php';
require_once AURA_CORE_PATH . 'class-activator.php';
require_once AURA_CORE_PATH . 'class-deactivator.php';
require_once AURA_PLUGIN_PATH . 'includes/class-assets.php';
require_once AURA_ADMIN_PATH . 'class-admin-menu.php';
require_once AURA_FRONTEND_PATH . 'class-gallery.php';
require_once AURA_FRONTEND_PATH . 'class-submission.php';

// Register activation and deactivation hooks
register_activation_hook(__FILE__, ['AURA_Activator', 'activate']);
register_deactivation_hook(__FILE__, ['AURA_Deactivator', 'deactivate']);

// Initialize the plugin
function aura_photo_awards_init() {
    $loader = new AURA_Loader();
    $loader->run();
}
add_action('plugins_loaded', 'aura_photo_awards_init');
